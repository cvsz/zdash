# zDash · Full System Blueprint v2.0 (Phase 9 Release-Ready)

Phase 9 upgrades this project from demo/in-memory patterns to a persistent, secured, deployable, observable release-ready platform.

## What Phase 9 Adds

- Database persistence with SQLModel entities and repository layer.
- Alembic migrations (`backend/alembic/*`).
- JWT authentication + RBAC (`admin`, `operator`, `analyst`, `viewer`).
- Protected dangerous actions with audit trail.
- Live trading hard gates with manual admin confirmation endpoint.
- FastAPI lifespan migration (startup/shutdown without deprecated `on_event`).
- Persistent event logs + paginated logs + SSE/WS stream.
- MT5 and Tapo adapter boundaries with diagnostics/readiness endpoints.
- Production Docker compose profile with Postgres, Redis, Nginx, healthchecks, volumes, networks, restart policies.
- Frontend login/session/role-aware nav/audit page/live warning banner/risk confirmations.
- Observability stack: request IDs, correlation IDs, Prometheus metrics, `/ready`, `/live`, `/metrics`.
- CI/CD workflows for backend/frontend/docker/security/release checks.
- Backup/restore scripts and incident/runbook documentation.
- Release patch/export artifacts under `release/phase9`.

## Safety Gates

Live trading remains blocked unless all are enabled:
- `DRY_RUN=false`
- `LIVE_TRADING_ACK=true`
- `RISK_GUARDIAN_ENABLED=true`
- `ADMIN_APPROVED_LIVE_MODE=true`
- manual approval via `POST /api/trading/live-mode/confirm`

## Key Endpoints (Phase 9)

- Auth:
  - `POST /api/auth/login`
  - `GET /api/auth/me`
- Logs:
  - `GET /api/logs?limit=100&offset=0`
  - `GET /api/logs/stream`
  - `GET /api/logs/ws`
- Audit:
  - `GET /api/audit`
- Risk hardening:
  - `POST /api/risk/emergency-halt`
  - `POST /api/risk/kill-switch-reset`
- Trading hardening:
  - `GET /api/trading/live-gates`
  - `POST /api/trading/live-mode/confirm`
  - `POST /api/trading/live-execute`
  - `GET /api/trading/mt5/diagnostics`
  - `GET /api/trading/mt5/symbol/{symbol}`
- IoT hardening:
  - `GET /api/scheduler/iot/connectivity`
  - `POST /api/scheduler/iot/power-cycle`

## Local Setup (SQLite)

```bash
./scripts/setup-dev.sh
source .venv/bin/activate
./scripts/migrate-db.sh
cd backend
pytest
uvicorn app.main:app --reload
```

Frontend:

```bash
cd frontend
npm install
npm run build
npm run dev
```

Smoke:

```bash
./scripts/smoke-test.sh http://127.0.0.1:8000 admin admin123
```

## Production Compose (Postgres + Redis + Nginx)

```bash
cp .env.production.example .env.production
# edit secrets before run

docker compose up -d --build
```

Observability profile:

```bash
docker compose --profile observability up -d
```

## Database Migration Commands

Upgrade:

```bash
./scripts/migrate-db.sh
```

Rollback one revision:

```bash
./scripts/rollback-db.sh
```

## Backup & Restore

```bash
./scripts/backup-db.sh
./scripts/backup-config.sh
./scripts/verify-backup.sh <backup-file>
./scripts/restore-db.sh <backup-file>
```

## Rollback Notes

- App rollback: redeploy prior image tag and run `./scripts/rollback-db.sh` if schema rollback is required.
- Risk rollback: use `POST /api/risk/emergency-halt` before deploy rollback if execution safety is uncertain.
- Auth rollback: rotate `JWT_SECRET_KEY` if token compromise is suspected.

## Verification Status (2026-05-24)

- Backend tests: pass (`36 passed, 1 warning`)
- Frontend build: pass
- Alembic upgrade: pass
- Docker compose config: pass (`docker compose config`, `docker compose --profile observability config`)

## Known Gaps

- MT5 and Tapo are still adapter shells; production drivers should replace internals behind interfaces.
- Redis is provisioned in compose but not yet used for queue fanout.
- SSE auth currently uses token query parameter for browser EventSource compatibility.
